package com.axelor.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.axelor.service.GoogleService;
import com.google.inject.Inject;
import com.google.inject.Singleton;

// It just like controller 

@Singleton
public class GoogleServlet extends  HttpServlet{

	private static final long serialVersionUID = 1L;
	

	@Inject
	private GoogleService googleService;
		
	
	/*
	 * Google Guice - Field Injection
	 * 
	 * @Inject
	private GoogleService googleService;
	
	*/
	
	
	/*
	 * Google Guice - Constructor Injection
	 * 
	 * @Inject
	public GoogleServlet(GoogleService googleService) {
		super();
		this.googleService = googleService;
	}*/

	
/*
 
 	Google Guice - Method Injection
 
	@Inject
	public void setGoogleService(GoogleService googleService) {
		this.googleService = googleService;
	}

*/

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		
		resp.getWriter().println(" Google Guice Srevlet !!! ");
		
		resp.getWriter().println(" Google Guice Srevlet !!! "+googleService.greetingMessage());
	}

}
