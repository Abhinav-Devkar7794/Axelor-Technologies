package com.axelor.service;

public interface UserService {

	
	String authenticate(String uname,String upass);
	
}
