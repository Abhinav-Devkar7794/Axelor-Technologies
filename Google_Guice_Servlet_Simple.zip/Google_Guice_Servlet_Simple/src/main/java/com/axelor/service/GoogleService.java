package com.axelor.service;

public interface GoogleService {

	
	String greetingMessage();
	
}
