package com.axelor.serviceimpl;

import javax.servlet.http.HttpServlet;

import com.axelor.service.GoogleService;

public class AmazonImple implements  GoogleService {

	@Override
	public String greetingMessage() {
		// TODO Auto-generated method stub
		return "Good Morning  Amazon !!!!";
	}

}
