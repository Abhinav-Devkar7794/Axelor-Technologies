package com.axelor.serviceimpl;

import com.axelor.service.UserService;

public class UserServiceImpl  implements UserService{

	@Override
	public String authenticate(String uname, String upass) {
		// TODO Auto-generated method stub
		String test="";
		if(uname.equals("test") && upass.equals("test")) {
			test="valid";
		}else {
			test="invalid";
		}
		
		return test;
	}

}
