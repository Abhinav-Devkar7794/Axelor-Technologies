package com.axelor.serviceimpl;

import com.axelor.service.GoogleService;

public class Flipcart implements GoogleService {

	@Override
	public String greetingMessage() {
		// TODO Auto-generated method stub
		return "Good Morning FlipCart !!!!";
	}
}
