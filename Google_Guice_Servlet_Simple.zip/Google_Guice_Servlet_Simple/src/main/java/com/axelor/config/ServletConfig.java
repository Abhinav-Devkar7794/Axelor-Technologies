package com.axelor.config;

import com.axelor.service.GoogleService;
import com.axelor.service.UserService;
import com.axelor.serviceimpl.AmazonImple;
import com.axelor.serviceimpl.Flipcart;
import com.axelor.serviceimpl.UserServiceImpl;
import com.axelor.servlet.AuthoriseServlet;
import com.axelor.servlet.GoogleServlet;
import com.axelor.servlet.LoginServlet;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.servlet.GuiceServletContextListener;
import com.google.inject.servlet.ServletModule;

public class ServletConfig  extends GuiceServletContextListener{

	@Override
	protected Injector getInjector() {
		// TODO Auto-generated method stub
		return Guice.createInjector(new ServletModule() {
			
			@Override
			protected void configureServlets() {
				// TODO Auto-generated method stub
				
				
				serve("/google").with(GoogleServlet.class);	
				serve("/login").with(LoginServlet.class);	
				serve("/authorise").with(AuthoriseServlet.class);	
				
				// if interface implemented by  class then binding is required
				bind(GoogleService.class).to(Flipcart.class);
				
				bind(UserService.class).to(UserServiceImpl.class);
				
			}
		});
	}

}
